package br.com.curso.de.programacao.meuprojetoweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MeuProjetoWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
