package br.com.curso.de.programacao.meuprojetoweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MeuProjetoWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(MeuProjetoWebApplication.class, args);
	}

}
